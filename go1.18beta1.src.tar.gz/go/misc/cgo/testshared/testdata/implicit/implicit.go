package implicit

func I() int {
	return 42
}
